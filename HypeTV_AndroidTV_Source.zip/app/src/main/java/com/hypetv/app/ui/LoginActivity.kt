package com.hypetv.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hypetv.app.R
import com.hypetv.app.data.GlobalConfig

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val prefs = getSharedPreferences(GlobalConfig.PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(GlobalConfig.KEY_IS_LOGGED_IN, false)) {
            // Already logged in, proceed to MainActivity
            startMainActivity()
            return
        }

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha usuário e senha", Toast.LENGTH_SHORT).show()
            } else {
                // Save session credentials
                prefs.edit().apply {
                    putString(GlobalConfig.KEY_USERNAME, username)
                    putString(GlobalConfig.KEY_PASSWORD, password)
                    putBoolean(GlobalConfig.KEY_IS_LOGGED_IN, true)
                    apply()
                }
                
                Toast.makeText(this, "Conectando ao Hype TV...", Toast.LENGTH_SHORT).show()
                startMainActivity()
            }
        }
    }

    private fun startMainActivity() {
        // Intent to launch main player UI
        finish()
    }
}
