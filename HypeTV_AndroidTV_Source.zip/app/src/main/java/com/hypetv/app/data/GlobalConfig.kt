package com.hypetv.app.data

object GlobalConfig {
    const val DEFAULT_DNS = "http://llonstrt.top"
    const val PLAYER_API_ENDPOINT = "$DEFAULT_DNS/player_api.php"
    
    // Auth Preferences Keys
    const val PREF_NAME = "HypeTV_Prefs"
    const val KEY_USERNAME = "username"
    const val KEY_PASSWORD = "password"
    const val KEY_IS_LOGGED_IN = "is_logged_in"
}
